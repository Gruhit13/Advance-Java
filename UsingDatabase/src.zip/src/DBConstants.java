
public interface DBConstants {
	final String MSAccessDriver = "net.ucanaccess.jdbc.UcanaccessDriver";
	final String SQLDriver = "com.mysql.jdbc.Driver";
	
	final String MsAccessDB = "jdbc:ucanaccess://C://Users//HOME//Desktop//CodeHere//Java//Advance Java//";
	final String SQLDB = "jdbc:mysql://localhost:3306/";
	final String username = "root";
	final String password = "";
}
