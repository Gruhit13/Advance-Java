import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InsertData implements DBConstants{
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		try {
			Class.forName(MSAccessDriver);
			try {
				Connection con = DriverManager.getConnection(MsAccessDB + "Database1.accdb");
				Statement stmt = con.createStatement();
				
				System.out.print("Enter furit Name:- "); String name = input.nextLine();
				System.out.print("Enter Price($):- "); float value = input.nextFloat();
				
				//	We need to pass id even if it is auto increemented
				
				String query = "INSERT INTO Fruits values(5, '" + name + "', " + value + ")";
				System.out.println("Query: " + query);
				
				int success = stmt.executeUpdate(query);
				
				if(success == 1) {
					System.out.println("Data Inserted Successfully");
				} else {
					System.out.println("Failed to insert data");
				}
				
				stmt.close();
				con.close();
				
				
				
			}catch(SQLException e) {
				System.out.println("Error: " + e);
			}
			
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}

	}

}
