import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.ResultSetMetaData;
import java.sql.DriverManager;

public class UsingSQL implements DBConstants {
	
	public static void showResult(Connection con_obj, String table) {
		try {
			Statement stmt = con_obj.createStatement();
			String query = "Select * from " + table;
			
			ResultSet res = stmt.executeQuery(query);
			
			ResultSetMetaData rsmd = res.getMetaData(); 
			int no_cols = rsmd.getColumnCount();
			
			
			System.out.println("Print result:- ");
			
			for(int j = 1; j <= no_cols; j++) {
				System.out.print(rsmd.getColumnName(j) + "\t");
			}
			
			System.out.println();
			while(res.next()) {
				for(int i = 1; i <= no_cols; i++) {
					System.out.print(res.getString(i) +" \t");
				}
				System.out.println();
			}
			
			stmt.close();
		}catch(SQLException e) {
			System.out.println("Error in displaying result: " + e);
		}
	}
	
	public static void main(String[] args) {
			try {
				Class.forName(SQLDriver);
				
				try {
					Connection con = DriverManager.getConnection(SQLDB+"learning", username, password);
					String query = "insert into students value(?, ?, ?)";
					
//					PreparedStatement pstmt = con.prepareStatement(query);
//					
//					pstmt.setInt(1,  5);
//					pstmt.setString(2, "Amrish");
//					pstmt.setString(3, "Anywhere");
//					
//					int result = pstmt.executeUpdate();
					
					//	System.out.println("Query Executed result = " + result);
					
					showResult(con, "students");
					//	pstmt.close();
					con.close();
				} catch(SQLException e) {
					System.out.println("Error: " + e);
				}
			} catch(ClassNotFoundException e) {
				System.out.println("Erro: " + e);
			}
	}

}
