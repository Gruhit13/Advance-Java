import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReadDB implements DBConstants {

	public static void main(String[] args) {
		try {
			Class.forName(MSAccessDriver);
			
//			
			try {
				//	Obtained Connection
				Connection con = DriverManager.getConnection(MsAccessDB + "Database1.accdb");
				
				//	Obtaining statement to execute query
				Statement stmt = con.createStatement();
				String query = "Select * from Table1";
				
				//	Executing query and storing result in ResultSet object
				ResultSet res = stmt.executeQuery(query);
				
				while(res.next()) {
					System.out.println("Name = " + res.getString("Name") + " Age = " + res.getInt("Age"));
				}
				
				stmt.close();
				con.close();
				
			} catch(SQLException e) {
				System.out.println("Error: " + e);
			}
		}catch(ClassNotFoundException e) {
			System.out.println("Class not found: " + e );
		}
	}

}
