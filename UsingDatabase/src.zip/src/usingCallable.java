import java.sql.*;
import java.util.Scanner;

public class usingCallable implements DBConstants {

	public static void main(String[] args) {
		Scanner inp = new Scanner(System.in);
		
		try {
			Class.forName(SQLDriver);
			
			Connection con = DriverManager.getConnection(SQLDB+"learning", username, password);
			
			//	Creating a callable object
			CallableStatement cs = con.prepareCall("{call remove(?, ?)}");
			
			cs.setInt(1, 5);
			//	Registering 2nd param as output
			cs.registerOutParameter(2, Types.INTEGER);
			
			cs.execute();
			
			System.out.println("Total number of rows left:- " + cs.getInt(2));
			
			con.close();
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
